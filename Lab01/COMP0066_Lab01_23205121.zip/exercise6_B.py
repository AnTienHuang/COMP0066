stored_password = 'password!' 
input_password = input('Type in the password: ')
if stored_password == input_password:
    print('Password accepted!')
else:
    print('Wrong Password')