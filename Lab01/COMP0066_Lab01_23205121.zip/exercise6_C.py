grade = int(input('Input the grade: '))
if grade >= 70:
    print('This is a Distinction')
elif grade >= 50:
    print('This is a Pass')
else:
    print('This is a Fail')