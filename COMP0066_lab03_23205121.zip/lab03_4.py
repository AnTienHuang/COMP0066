l1 = [1, 2, 3]
l2 = ['Apple', 'Banana', 'Cucumber']
for item in zip(l1, l2):
    print(item)