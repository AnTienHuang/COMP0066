def x(n):
    return n ** 2 + 1

print(x(4))